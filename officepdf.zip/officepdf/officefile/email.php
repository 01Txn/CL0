<?php 
$Receive_email="evil-sms@gmail.com";

?>